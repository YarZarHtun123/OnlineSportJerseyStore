﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Admin_LogIn : System.Web.UI.Page
{
    MainDataSetTableAdapters.AdminTableAdapter adminTable = new MainDataSetTableAdapters.AdminTableAdapter();

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void LogInButton_Click(object sender, EventArgs e)
    {
        DataTable adminDataTable = new DataTable();
        if (this.IsNotNullorEmpty())
        {
            adminDataTable = adminTable.Admin_Select_By_AdminNamePassword(adminNameTextBox.Text, passwordTextBox.Text);
            if (adminDataTable.Rows.Count > 0)
            {
                Session["LogInAdmin"] = adminDataTable.Rows[0][1];
                Response.Redirect("AddCategory.aspx");
            }
            else
            {
                errorLabel.Text = "Please Retype AdminName And Password";
            }
        }
    }

    private bool IsNotNullorEmpty()
    {
        if (string.IsNullOrEmpty(adminNameTextBox.Text.Trim()) || string.IsNullOrWhiteSpace(adminNameTextBox.Text.Trim()))
        {
            errorLabel.Text = "Please Type AdminName";
            adminNameTextBox.Focus();
            return false;
        }
        else if (string.IsNullOrEmpty(passwordTextBox.Text.Trim()) || string.IsNullOrWhiteSpace(passwordTextBox.Text.Trim()))
        {
            errorLabel.Text = "Please Type Password";
            passwordTextBox.Focus();
            return false;
        }
        else
        {
            return true;
        }
    }
}