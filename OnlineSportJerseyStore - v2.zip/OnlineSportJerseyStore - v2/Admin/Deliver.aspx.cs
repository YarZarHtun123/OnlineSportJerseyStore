﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Admin_Deliver : System.Web.UI.Page
{
    MainDataSetTableAdapters.Admin_OrderTableAdapter adminOrderTable = new MainDataSetTableAdapters.Admin_OrderTableAdapter();
    MainDataSetTableAdapters.OrderTableAdapter orderTable = new MainDataSetTableAdapters.OrderTableAdapter();
    private DataTable adminOrderDataTable = new DataTable();
    private DataTable displayDataTable = new DataTable();

    protected void DisplayAdminOrder()
    {
        DataRow displayDataRow;
        displayDataTable.Columns.Clear();
        displayDataTable.Rows.Clear();
        displayDataTable.Columns.Add("No");
        displayDataTable.Columns.Add("OrderID");
        displayDataTable.Columns.Add("OrderDate");
        displayDataTable.Columns.Add("CustName");
        displayDataTable.Columns.Add("ShippingAdd");
        displayDataTable.Columns.Add("Total");
        displayDataTable.Columns.Add("DeliverStatus");
        displayDataRow = displayDataTable.NewRow();
        displayDataTable.Rows.Add(displayDataRow);

        if (adminOrderDataTable.Rows.Count > 0)
        {
            displayDataTable.Rows.Clear();
            foreach (DataRow dataRow1 in adminOrderDataTable.Rows)
            {
                displayDataRow = displayDataTable.NewRow();
                displayDataRow[0] = dataRow1[0];
                displayDataRow[1] = dataRow1[1];
                displayDataRow[2] = dataRow1[2];
                displayDataRow[3] = dataRow1[4];
                displayDataRow[4] = dataRow1[5];
                displayDataRow[5] = dataRow1[6];
                displayDataRow[6] = dataRow1[7];
                displayDataTable.Rows.Add(displayDataRow);
            }
        }
        deliverGridView.DataSource = displayDataTable;
        deliverGridView.DataBind();
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        adminOrderDataTable = adminOrderTable.Admin_Order_Select_By_Deliver();
        this.DisplayAdminOrder();
    }

    protected void UpdateButton_Click(object sender, EventArgs e)
    {
        var deliverStatus = String.Empty;
        var orderID = Convert.ToInt32(orderIDTextBox.Text);
        if (this.IsSelectCheckBoxs())
        {
            if (deliverRadioButton.Checked == true)
            {
                deliverStatus = "Deliver";
                adminOrderTable.Admin_Order_Update(orderID, deliverStatus);
                orderTable.Order_NotiStatus_Update(Convert.ToInt32(orderID), "Y");
                Response.Redirect("Deliver.aspx");
            }
            else if (notEnoughQuantityRadioButton.Checked == true)
            {
                deliverStatus = "Not Enought Qty";
                adminOrderTable.Admin_Order_Update(orderID, deliverStatus);
                orderTable.Order_NotiStatus_Update(Convert.ToInt32(orderID), "Y");
                Response.Redirect("Deliver.aspx");
            }
            else if (pendingRadioButton.Checked == true)
            {
                deliverStatus = "Pending";
                adminOrderTable.Admin_Order_Update(orderID, deliverStatus);
                orderTable.Order_NotiStatus_Update(Convert.ToInt32(orderID), "Y");
                Response.Redirect("Deliver.aspx");
            }
        }
    }

    protected void DeliverGridView_SelectedIndexChanged(object sender, EventArgs e)
    {
        var rowIndex = deliverGridView.SelectedIndex;
        orderIDTextBox.Text = displayDataTable.Rows[rowIndex][1].ToString();
        GridViewRow deliverGridViewRow = deliverGridView.Rows[rowIndex];
        CheckBox selectCheckBox = (CheckBox)deliverGridViewRow.FindControl("selectCheckBox");
        selectCheckBox.Checked = true;
    }

    private bool IsSelectCheckBoxs()
    {
        if (orderIDTextBox.Text.ToString() == string.Empty)
        {
            errorLabel.Text = "Please Select OrderID";
            return false;
        }
        if (deliverRadioButton.Checked == false && notEnoughQuantityRadioButton.Checked == false && pendingRadioButton.Checked == false)
        {
            errorLabel.Text = "Please Choose Deliver Status";
            return false;
        }
        else
        {
            return true;
        }
    }
}