﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
public partial class Admin_AddItem : System.Web.UI.Page
{
    MainDataSetTableAdapters.ItemTableAdapter itemTable = new MainDataSetTableAdapters.ItemTableAdapter();
    MainDataSetTableAdapters.CategoryTableAdapter categoryTable = new MainDataSetTableAdapters.CategoryTableAdapter();
    private DataTable itemDataTable = new DataTable();

    protected void Page_Load(object sender, EventArgs e)
    {
        DataTable categoryDataTable = new DataTable();
        Page.MaintainScrollPositionOnPostBack = true;
        if (Page.IsPostBack == false)
        {
            this.BindGridView();
            categoryDataTable = categoryTable.GetData();
            categoryDropDownList.DataSource = categoryDataTable;
            categoryDropDownList.DataTextField = "CatName";
            categoryDropDownList.DataValueField = "CatID";
            categoryDropDownList.DataBind();
        }
    }
    protected void AddButton_Click(object sender, EventArgs e)
    {
         if (this.IsNotDuplicate())
        {
            this.InsertData();
            this.BindGridView();
            errorLabel.Text = "Item is Added";
        }
         clear();
    }
    protected void ItemGridView_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        itemGridView.EditIndex = -1;
        this.BindGridView();
    }
    protected void ItemGridView_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
         var itemID = Convert.ToInt32(itemGridView.DataKeys[e.RowIndex].Value);
        if (this.IsNotInstock(itemID))
        {
            itemTable.Item_Delete(itemID);
            this.BindGridView();
        }
    }
    protected void ItemGridView_RowEditing(object sender, GridViewEditEventArgs e)
    {
         itemGridView.EditIndex = e.NewEditIndex;
        this.BindGridView();
    }
    protected void ItemGridView_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
         TextBox priceTextBox = itemGridView.Rows[e.RowIndex].Cells[3].Controls[0] as TextBox;
        if (this.IsNotOverPrice(priceTextBox.Text.ToString()))
        {
            var itemID = Convert.ToInt32(itemGridView.DataKeys[e.RowIndex].Value);
            TextBox itemNameTextBox = itemGridView.Rows[e.RowIndex].Cells[2].Controls[0] as TextBox;
            itemTable.Item_Update(itemID, itemNameTextBox.Text, Convert.ToInt32(priceTextBox.Text));
            itemGridView.EditIndex = -1;
            this.BindGridView();
        }
    }

    private bool IsNotDuplicate()
    {
        itemDataTable = itemTable.Item_Select_By_ItemNameCatName(itemNameTextBox.Text, categoryDropDownList.SelectedItem.ToString());
        if (itemDataTable.Rows.Count > 0)
        {
            errorLabel.Text = "This Item Is Already Exist";
        }
        return !(itemDataTable.Rows.Count > 0);
    }

    private bool IsNotOverPrice(string priceTextBox)
    {
        var maximumPrice = 999999;
        if (Convert.ToInt32(priceTextBox) >= maximumPrice)
        {
            errorLabel.Text = "Over Price";
        }
        return !(Convert.ToInt32(priceTextBox) >= maximumPrice);
    }

    private bool IsNotInstock(int itemID)
    {
        itemDataTable = itemTable.Item_Select_By_ItemID(itemID);
        if (Convert.ToInt32(itemDataTable.Rows[0][6].ToString()) > 0)
        {
            errorLabel.Text = "This Item Have Instock" + itemDataTable.Rows[0][6].ToString();
        }
        return !(Convert.ToInt32(itemDataTable.Rows[0][6].ToString()) > 0);
    }

    private void BindGridView()
    {
        itemDataTable = itemTable.GetData();
        itemGridView.DataSource = itemDataTable;
        itemGridView.DataBind();
    }

    private void InsertData()
    {
        imageFileUpload.SaveAs(string.Format("{0}{1}", Server.MapPath("~/img/"), imageFileUpload.FileName));
        itemTable.Item_Insert(categoryDropDownList.SelectedItem.Text, itemNameTextBox.Text, Convert.ToInt32(priceTextBox.Text),
        Convert.ToInt32(quantityTextBox.Text), Convert.ToInt32(quantityTextBox.Text), 0, "~/img/" + imageFileUpload.FileName,
        sizeDropDownList.SelectedItem.Text, Convert.ToInt32(categoryDropDownList.SelectedValue));
    }

    private void clear()
    {
        itemNameTextBox.Text = "";
        priceTextBox.Text = "";
        quantityTextBox.Text = "";
        
        
    }
}