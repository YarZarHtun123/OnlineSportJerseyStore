﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Admin_ChangePassword : System.Web.UI.Page
{
    MainDataSetTableAdapters.AdminTableAdapter adminTable = new MainDataSetTableAdapters.AdminTableAdapter();

    protected void SaveButton_Click(object sender, EventArgs e)
    {
        adminTable.Admin_Update_Password("admin", passwordTextBox.Text);
        messageLabel.Text = "Password Changed";
    }
}