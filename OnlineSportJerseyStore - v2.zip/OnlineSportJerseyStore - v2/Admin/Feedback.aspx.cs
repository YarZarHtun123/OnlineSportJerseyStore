﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Admin_Feedback : System.Web.UI.Page
{
    MainDataSetTableAdapters.FeedbackTableAdapter feedbackTable = new MainDataSetTableAdapters.FeedbackTableAdapter();
    private DataTable feedbackDataTable = new DataTable();

    protected void DisplayFeedback()
    {
        DataTable displayDataTable = new DataTable();
        DataRow displayDataRow;
        displayDataTable.Columns.Clear();
        displayDataTable.Rows.Clear();
        displayDataTable.Columns.Add("FID");
        displayDataTable.Columns.Add("CustName");
        displayDataTable.Columns.Add("Message");
        displayDataRow = displayDataTable.NewRow();
        displayDataTable.Rows.Add(displayDataRow);
        if (feedbackDataTable.Rows.Count > 0)
        {
            displayDataTable.Rows.Clear();
            foreach (DataRow dataRow1 in feedbackDataTable.Rows)
            {
                displayDataRow = displayDataTable.NewRow();
                displayDataRow[0] = dataRow1[0];
                displayDataRow[1] = dataRow1[1];
                displayDataRow[2] = dataRow1[2];
                displayDataTable.Rows.Add(displayDataRow);
            }
        }
        feedbackGridView.DataSource = displayDataTable;
        feedbackGridView.DataBind();
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        feedbackDataTable = feedbackTable.GetData();
        this.DisplayFeedback();
    }
}