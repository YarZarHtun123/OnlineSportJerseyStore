﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Admin_ViewOrder : System.Web.UI.Page
{
    MainDataSetTableAdapters.CustomerTableAdapter customerTable = new MainDataSetTableAdapters.CustomerTableAdapter();
    MainDataSetTableAdapters.Admin_OrderDetailTableAdapter adminOrderDetailTable = new MainDataSetTableAdapters.Admin_OrderDetailTableAdapter();
    private DataTable orderDetailDataTable = new DataTable();

    protected void Page_Load(object sender, EventArgs e)
    {
        DataTable customerDataTable = new DataTable();
        if (Page.IsPostBack == false)
        {
            orderDetailDataTable = adminOrderDetailTable.GetData();
            customerDataTable = customerTable.GetData();
            customerNameDropDownList.DataSource = customerDataTable;
            customerNameDropDownList.DataTextField = "CustName";
            customerNameDropDownList.DataValueField = "CustID";
            customerNameDropDownList.DataBind();
        }
    }

    protected void ViewButton_Click(object sender, EventArgs e)
    {
        orderDetailDataTable = adminOrderDetailTable.Admin_OrderDetail_Select_By_CustNameStatus(customerNameDropDownList.SelectedItem.Text, orderStatusDropDownList.SelectedItem.Text);
        orderGridView.DataSource = orderDetailDataTable;
        orderGridView.DataBind();
    }

    protected void OrderGridView_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {
        orderGridView.PageIndex = e.NewSelectedIndex;
        orderDetailDataTable = adminOrderDetailTable.Admin_OrderDetail_Select_By_CustNameStatus(customerNameDropDownList.SelectedItem.Text, orderStatusDropDownList.SelectedItem.Text);
        orderGridView.DataSource = orderDetailDataTable;
        orderGridView.DataBind();
    }
}