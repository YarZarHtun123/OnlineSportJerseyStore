﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Admin_Reports : System.Web.UI.Page
{
    MainDataSetTableAdapters.ItemTableAdapter itemTable = new MainDataSetTableAdapters.ItemTableAdapter();
    MainDataSetTableAdapters.CategoryTableAdapter categoryTable = new MainDataSetTableAdapters.CategoryTableAdapter();

    protected void Page_Load(object sender, EventArgs e)
    {
        DataTable categoryDataTable = new DataTable();
        errorLabel.Text = string.Empty;
        if (Page.IsPostBack == false)
        {
            categoryDataTable = categoryTable.GetData();
            categoryDropDownList.DataSource = categoryDataTable;
            categoryDropDownList.DataTextField = "CatName";
            categoryDropDownList.DataValueField = "CatID";
            categoryDropDownList.DataBind();
            categoryDropDownList.Items.Insert(0, "SELECT");
        }
    }

    protected void ViewButton_Click(object sender, EventArgs e)
    {
        DataTable itemDataTable = new DataTable();
        itemDataTable = itemTable.Item_Select_SearchCatName(categoryDropDownList.SelectedItem.Text);
        reportGridView.DataSource = itemDataTable;
        reportGridView.DataBind();
        errorLabel.Text = string.Format("{0}{1}{2}", "Total ", reportGridView.Rows.Count.ToString(), " Record Found");
    }
}