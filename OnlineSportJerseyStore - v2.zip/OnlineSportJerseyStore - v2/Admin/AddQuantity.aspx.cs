﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Admin_AddQuantity : System.Web.UI.Page
{
    MainDataSetTableAdapters.ItemTableAdapter itemTable = new MainDataSetTableAdapters.ItemTableAdapter();
    private DataTable itemDataTable = new DataTable();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack == false)
        {
            itemDataTable = itemTable.GetData();
            quantityGridView.DataSource = itemDataTable;
            quantityGridView.DataBind();
            itemDataTable = itemTable.GetData();
            itemDropDownList.DataSource = itemDataTable;
            itemDropDownList.DataTextField = "ItemName";
            itemDropDownList.DataValueField = "ItemID";
            itemDropDownList.DataBind();
        }
    }

    protected void AddButton_Click(object sender, EventArgs e)
    {

        this.AddQuantity();
        errorLabel.Text = "YOUR QUANTITY IS UPDATED";
        this.BindGridView();
        quantityTextBox.Text = String.Empty;
    }

    private void AddQuantity()
    {
        itemTable.Item_Add_Quantity(Convert.ToInt32(itemDropDownList.SelectedValue), Convert.ToInt32(quantityTextBox.Text), Convert.ToInt32(quantityTextBox.Text));
    }

    private void BindGridView()
    {
        itemDataTable = itemTable.Item_Select_By_ItemID(Convert.ToInt32(itemDropDownList.SelectedValue));
        itemDataTable = itemTable.GetData();
        quantityGridView.DataSource = itemDataTable;
        quantityGridView.DataBind();
    }
}