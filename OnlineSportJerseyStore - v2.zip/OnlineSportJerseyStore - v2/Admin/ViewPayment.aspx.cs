﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Admin_ViewPayment : System.Web.UI.Page
{
    MainDataSetTableAdapters.PaymentTableAdapter paymentTable = new MainDataSetTableAdapters.PaymentTableAdapter();
    MainDataSetTableAdapters.CustomerTableAdapter customerTable = new MainDataSetTableAdapters.CustomerTableAdapter();

    protected void Page_Load(object sender, EventArgs e)
    {
        DataTable customerDataTable = new DataTable();
        if (Page.IsPostBack == false)
        {
            customerDataTable = customerTable.GetData();
            customerNameDropDownList.DataSource = customerDataTable;
            customerNameDropDownList.DataTextField = "CustName";
            customerNameDropDownList.DataValueField = "CustID";
            customerNameDropDownList.DataBind();
        }
    }

    protected void ViewButton_Click(object sender, EventArgs e)
    {
        DataTable paymentDataTable = new DataTable();
        paymentDataTable = paymentTable.Payment_Select_By_CustName(customerNameDropDownList.SelectedItem.Text);
        paymentGridView.DataSource = paymentDataTable;
        paymentGridView.DataBind();
    }
}