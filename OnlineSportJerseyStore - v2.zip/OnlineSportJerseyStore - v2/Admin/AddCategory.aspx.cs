﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Admin_AddCategory : System.Web.UI.Page
{
    MainDataSetTableAdapters.CategoryTableAdapter categoryTable = new MainDataSetTableAdapters.CategoryTableAdapter();
    private DataTable categoryDataTable = new DataTable();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack == false)
        {
            this.BindGridView();
        }
    }

    protected void CategoryGridView_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        categoryGridView.EditIndex = -1;
        this.BindGridView();
    }

    protected void CategoryGridView_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        var categoryID = Convert.ToInt32(categoryGridView.DataKeys[e.RowIndex].Value);
        this.DeleteData(categoryID);
    }

    protected void CategoryGridView_RowEditing(object sender, GridViewEditEventArgs e)
    {
        categoryGridView.EditIndex = e.NewEditIndex;
        this.BindGridView(); 
    }

    protected void CategoryGridView_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        var categoryID = Convert.ToInt32(categoryGridView.DataKeys[e.RowIndex].Value);
        TextBox categoryTextBox = categoryGridView.Rows[e.RowIndex].Cells[2].Controls[0] as TextBox;
        if (this.IsNotDuplicateForUpdate(categoryTextBox.Text.ToString()))
        {
            this.UpdateData(categoryID, categoryTextBox.Text.ToString());
        }
    }

    protected void AddButton_Click(object sender, EventArgs e)
    {
        if (this.IsNotDuplicateForAdd())
        {
            categoryTable.Category_Insert(categoryNameTextBox.Text);
            this.BindGridView();

        }
        categoryNameTextBox.Text = "";

    }

    private bool IsNotDuplicateForAdd()
    {
        categoryDataTable = categoryTable.Category_Select_By_CatName(categoryNameTextBox.Text);
        if (categoryDataTable.Rows.Count > 0)
        {
            errorLabel.Text = "This Category Is Already Exist";
            categoryNameTextBox.Focus();
        }
        return !(categoryDataTable.Rows.Count > 0);
    }

    private bool IsNotDuplicateForUpdate(string categoryTextBox)
    {
        categoryDataTable = categoryTable.Category_Select_By_CatName(categoryTextBox);
        if (categoryDataTable.Rows.Count > 0)
        {
            errorLabel.Text = "This Category Is Already Exist";
        }
        return !(categoryDataTable.Rows.Count > 0);
    }

    private void DeleteData(int categoryID)
    {
        categoryTable.Category_Delete(categoryID);
        this.BindGridView();
    }

    private void UpdateData(int categoryID, string categoryTextBox)
    {
        categoryTable.Category_Update(categoryID, categoryTextBox);
        categoryGridView.EditIndex = -1;
        this.BindGridView();
    }

    private void BindGridView()
    {
        categoryDataTable = categoryTable.GetData();
        categoryGridView.DataSource = categoryDataTable;
        categoryGridView.DataBind();
    }
}