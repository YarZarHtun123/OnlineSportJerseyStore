﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class User_ChangePassword : System.Web.UI.Page
{
    MainDataSetTableAdapters.CustomerTableAdapter customerTable = new MainDataSetTableAdapters.CustomerTableAdapter();

    protected void ChangeButton_Click(object sender, EventArgs e)
    {
        customerTable.Customer_Update_Password(Session["customerName"].ToString(), passwordTextBox.Text);
        messageLabel.Text = "Password changed successfully";
    }
}