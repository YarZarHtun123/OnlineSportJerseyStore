﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class User_MyOrder : System.Web.UI.Page
{
    
    MainDataSetTableAdapters.Admin_OrderDetailTableAdapter adminOrderDetailTable = new MainDataSetTableAdapters.Admin_OrderDetailTableAdapter();
    private DataTable orderDetailDataTable = new DataTable();

    private void DisplayAdminOrder()
    {
        DataTable displayDataTable = new DataTable();
        DataRow displayDataRow;
        displayDataTable.Columns.Clear();
        displayDataTable.Rows.Clear();
        displayDataTable.Columns.Add("Image");
        displayDataTable.Columns.Add("OrderID");
        displayDataTable.Columns.Add("ItemName");
        displayDataTable.Columns.Add("CatName");
        displayDataTable.Columns.Add("UnitPrice");
        displayDataTable.Columns.Add("Quantity");
        displayDataTable.Columns.Add("OrderDate");
        displayDataRow = displayDataTable.NewRow();
        displayDataTable.Rows.Add(displayDataRow);
        if (orderDetailDataTable.Rows.Count > 0)
        {
            displayDataTable.Rows.Clear();
            foreach (DataRow dataRow1 in orderDetailDataTable.Rows)
            {
                displayDataRow = displayDataTable.NewRow();
                displayDataRow[0] = dataRow1[3];
                displayDataRow[1] = dataRow1[1];
                displayDataRow[2] = dataRow1[4];
                displayDataRow[3] = dataRow1[5];
                displayDataRow[4] = dataRow1[6];
                displayDataRow[5] = dataRow1[7];
                displayDataRow[6] = dataRow1[10];
                displayDataTable.Rows.Add(displayDataRow);
            }
        }
        orderGridView.DataSource = displayDataTable;
        orderGridView.DataBind();
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        var customerName = Session["customerName"].ToString();
        orderDetailDataTable = adminOrderDetailTable.Admin_OrderDetail_Select_By_CustNameStatus(customerName, "Order...");
        this.DisplayAdminOrder();
    }
}