﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class User_MyCart : System.Web.UI.Page
{
    MainDataSetTableAdapters.ItemTableAdapter ItemTbl = new MainDataSetTableAdapters.ItemTableAdapter();
    private DataTable itemDataTable = new DataTable();
    private DataTable displayDataTable = new DataTable();

    protected void Page_Load(object sender, EventArgs e)
    {
        itemDataTable = (DataTable)Session["TempTbl"];
        if (Session["TempTbl"] == null)
        {
            Response.Redirect("Default.aspx");
        }
        else
        {
            if (itemDataTable.Rows.Count <= 0)
            {
                Response.Redirect("Default.aspx");
            }
            else
            {
                this.SelectTempTbl();
            }
        }
    }

    protected void SelectTempTbl()
    {
        DataTable dataTable = new DataTable();
        DataRow displayDataRow;
        displayDataTable.Columns.Clear();
        displayDataTable.Rows.Clear();
        displayDataTable.Columns.Add("No");
        displayDataTable.Columns.Add("ItemID");
        displayDataTable.Columns.Add("ItemName");
        displayDataTable.Columns.Add("CatName");
        displayDataTable.Columns.Add("Price");
        displayDataTable.Columns.Add("Qty");

        var index = 0;
        foreach (DataRow dataRow1 in itemDataTable.Rows)
        {
            var itemID = Convert.ToInt32(dataRow1[0]);
            dataTable = ItemTbl.Item_Select_By_ItemID(itemID);
            foreach (DataRow dataRow2 in dataTable.Rows)
            {
                displayDataRow = displayDataTable.NewRow();
                displayDataRow[0] = index + 1;
                displayDataRow[1] = dataRow2[1];
                displayDataRow[2] = dataRow2[3];
                displayDataRow[3] = dataRow2[2];
                displayDataRow[4] = dataRow2[4];
                displayDataRow[5] = dataRow1[1];
                displayDataTable.Rows.Add(displayDataRow);
                cartGridView.DataSource = displayDataTable;
                cartGridView.DataBind();
                index = index + 1;
            }
            
        }


    }

    protected void CheckOutButton_Click(object sender, EventArgs e)
    {
        if (itemDataTable.Rows.Count != 0)
        {
            Response.Redirect("CheckOut.aspx");
        }
        else
        {
            Response.Redirect("Default.aspx");
        }    
    }

    protected void CartGridView_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        itemDataTable.Rows.RemoveAt(e.RowIndex);
        this.SelectTempTbl();
        cartGridView.DataSource = displayDataTable;
        cartGridView.DataBind();
    }
}