﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
public partial class User_ProductDetail : System.Web.UI.Page
{
    MainDataSetTableAdapters.ItemTableAdapter itemTable = new MainDataSetTableAdapters.ItemTableAdapter();

    protected void Page_Load(object sender, EventArgs e)
    {
        DataTable itemDataTable = new DataTable();
        if (Page.IsPostBack == false)
        {
            var ItemID = Request.QueryString["ItemID"].ToString();
            itemDataTable = itemTable.Item_Select_By_ItemID(Convert.ToInt32(ItemID));
            itemNameLabel.Text = itemDataTable.Rows[0]["ItemName"].ToString();
            priceLabel.Text = itemDataTable.Rows[0]["Price"].ToString();
            Image3.ImageUrl = itemDataTable.Rows[0]["image"].ToString();
            sizeLabel.Text = itemDataTable.Rows[0]["Size"].ToString();
            itemDataTable = itemTable.Item_Select_Top7();
            itemDataList.DataSource = itemDataTable;
            itemDataList.DataBind();
        }
    }

    protected void ItemDataList_ItemCommand(object source, DataListCommandEventArgs e)
    {
        Response.Redirect("ProductDetail.aspx?ItemID=" + e.CommandArgument.ToString());
    }
}