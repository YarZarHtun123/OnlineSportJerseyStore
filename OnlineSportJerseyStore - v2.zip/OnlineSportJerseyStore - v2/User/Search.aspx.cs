﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class User_Search : System.Web.UI.Page
{
    MainDataSetTableAdapters.ItemTableAdapter itemTable = new MainDataSetTableAdapters.ItemTableAdapter();

    protected void Page_Load(object sender, EventArgs e)
    {
        DataTable itemDataTable = new DataTable();
        if (Page.IsPostBack == false)
        {
            itemDataTable = itemTable.Item_Select_SearchCatName(Session["categoryName"].ToString());
            itemDataList.DataSource = itemDataTable;
            itemDataList.DataBind();
        }
    }

    protected void ItemDataList_ItemCommand(object source, DataListCommandEventArgs e)
    {
        Session["ItemID"] = e.CommandArgument.ToString();
        Response.Redirect("View.aspx?ItemID=" + e.CommandArgument.ToString());
    }
}