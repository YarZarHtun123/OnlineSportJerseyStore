﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class User_Product : System.Web.UI.Page
{
    MainDataSetTableAdapters.CustomerTableAdapter customerTable = new MainDataSetTableAdapters.CustomerTableAdapter();
    MainDataSetTableAdapters.CategoryTableAdapter categoryTable = new MainDataSetTableAdapters.CategoryTableAdapter();
    MainDataSetTableAdapters.ItemTableAdapter itemTable = new MainDataSetTableAdapters.ItemTableAdapter();
    private DataTable itemDataTable = new DataTable();

    protected void Page_Load(object sender, EventArgs e)
    {
        DataTable categoryDataTable = new DataTable();
        categoryDataTable = categoryTable.GetData();
        itemGridView.DataSource = categoryDataTable;
        itemGridView.DataBind();
        itemDataTable = itemTable.Item_Select_Top12();
        productDataList.DataSource = itemDataTable;
        productDataList.DataBind();
    }

    protected void ProductDataList_ItemCommand(object source, DataListCommandEventArgs e)
    {
        Response.Redirect("ProductDetail.aspx?ItemID=" + e.CommandArgument.ToString());
    }

    protected void LogInButton_Click(object sender, EventArgs e)
    {
        if (this.IsCorrectLogIn())
        {
            Response.Redirect("Default.aspx");
        }
        else
        {
            errorLabel.Text = "Error !!!";
        }
    }

    protected void ItemGridView_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        itemDataTable = itemTable.Item_Select_SearchCatName(e.CommandArgument.ToString());
        productDataList.DataSource = itemDataTable;
        productDataList.DataBind();
    }

    private bool IsCorrectLogIn()
    {
        DataTable customerDataTable = new DataTable();
        customerDataTable = customerTable.Customer_Select_for_LogIn(customerNameTextBox.Text, passwordTextBox.Text);
        if (customerDataTable.Rows.Count > 0)
        {
            Session["LogInCustomer"] = customerDataTable.Rows[0][1].ToString();
            Session["customerName"] = customerNameTextBox.Text;
        }
        return customerDataTable.Rows.Count > 0;
    }
}