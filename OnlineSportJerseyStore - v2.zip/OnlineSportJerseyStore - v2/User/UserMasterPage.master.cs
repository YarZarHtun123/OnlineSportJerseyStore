﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class User_UserMasterPage : System.Web.UI.MasterPage
{
    MainDataSetTableAdapters.CategoryTableAdapter categoryTable = new MainDataSetTableAdapters.CategoryTableAdapter();
    MainDataSetTableAdapters.CustomerTableAdapter customerTable = new MainDataSetTableAdapters.CustomerTableAdapter();

    protected void Page_Load(object sender, EventArgs e)
    {
        DataTable categoryDataTable = new DataTable();
        categoryDataTable = categoryTable.GetData();
        itemGridView.DataSource = categoryDataTable;
        itemGridView.DataBind();
        customerNameTextBox.Focus();
    }

    protected void ItemGridView_RowCommand1(object sender, GridViewCommandEventArgs e)
    {
        Session["name"] = e.CommandArgument.ToString();
    }

    protected void LogInButton_Click(object sender, EventArgs e)
    {
        if (this.IsNotNullorEmpty())
        {
            if (this.IsCorrectLogIn())
            {
                Response.Redirect("Default.aspx");
            }
            else
            {
                errorLabel.Text = "Please Retype Username And Password";
            }
        }
    }

    private bool IsCorrectLogIn()
    {
        DataTable customerDataTable = new DataTable();
        customerDataTable = customerTable.Customer_Select_for_LogIn(customerNameTextBox.Text, passwordTextBox.Text);

        if (customerDataTable.Rows.Count > 0)
        {
            Session["LogInCustomer"] = customerDataTable.Rows[0][1].ToString();
            Session["customerName"] = customerNameTextBox.Text;
        }
        return customerDataTable.Rows.Count > 0;
    }

    private bool IsNotNullorEmpty()
    {
        if (string.IsNullOrEmpty(customerNameTextBox.Text.Trim()) || string.IsNullOrWhiteSpace(customerNameTextBox.Text.Trim())
            && string.IsNullOrEmpty(passwordTextBox.Text.Trim()) || string.IsNullOrWhiteSpace(passwordTextBox.Text.Trim()))
        {
            errorLabel.Text = "Please Type Username and Password";
            customerNameTextBox.Focus();
            return false;
        }
        else if (string.IsNullOrEmpty(customerNameTextBox.Text.Trim()) || string.IsNullOrWhiteSpace(customerNameTextBox.Text.Trim()))
        {
            errorLabel.Text = "Please Type Username";
            customerNameTextBox.Focus();
            return false;
        }
        else if (string.IsNullOrEmpty(passwordTextBox.Text.Trim()) || string.IsNullOrWhiteSpace(passwordTextBox.Text.Trim()))
        {
            errorLabel.Text = "Please Type Password";
            passwordTextBox.Focus();
            return false;
        }
        else
        {
            return true;
        }
    }
}
