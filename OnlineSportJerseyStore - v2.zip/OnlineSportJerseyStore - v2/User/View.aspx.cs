﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class User_View : System.Web.UI.Page
{
    MainDataSetTableAdapters.ItemTableAdapter itemTable = new MainDataSetTableAdapters.ItemTableAdapter();

    protected void Page_Load(object sender, EventArgs e)
    {
        DataTable itemDataTable = new DataTable();
        if (Page.IsPostBack == false)
        {
            var ItemID = Request.QueryString["ItemID"].ToString();
            itemDataTable = itemTable.Item_Select_By_ItemID(Convert.ToInt32(ItemID));
            itemNameLabel.Text = itemDataTable.Rows[0]["ItemName"].ToString();
            priceLabel.Text = itemDataTable.Rows[0]["Price"].ToString();
            itemImage.ImageUrl = itemDataTable.Rows[0]["image"].ToString();
            quantityLabel.Text = itemDataTable.Rows[0]["Size"].ToString();
            itemDataTable = itemTable.Item_Select_Top7();
            itemDataList.DataSource = itemDataTable;
            itemDataList.DataBind();
        }
    }

    protected void AddButton_Click(object sender, EventArgs e)
    {
        DataTable dataTable = new DataTable();
        DataRow dataRow;
        dataTable.Columns.Add("ItemID");
        dataTable.Columns.Add("Quantity");
        dataTable.Rows.Clear();
        if (Session["TempTbl"] != null)
        {
            dataTable = (DataTable)Session["TempTbl"];
            DataRow[] dataRowArray = dataTable.Select("ItemID='" + Session["ItemID"] + "'");
            foreach (DataRow dataRow1 in dataRowArray)
            {
                dataRow1[1] = Convert.ToInt32(dataRow1[1]) + 1;
                dataTable.AcceptChanges();
                Session["TempTbl"] = dataTable;
                Response.Redirect("MyCart.aspx");
                return;
            }
        }
        dataRow = dataTable.NewRow();
        dataRow[0] = Session["ItemID"];
        dataRow[1] = 1;
        dataTable.Rows.Add(dataRow);
        Session["TempTbl"] = dataTable;
        Response.Redirect("MyCart.aspx");
    }

    protected void ItemDataList_ItemCommand(object source, DataListCommandEventArgs e)
    {
        Response.Redirect("View.aspx?ItemID=" + e.CommandArgument.ToString());
    }
}