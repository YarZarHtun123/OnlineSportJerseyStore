﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class User_Default : System.Web.UI.Page
{
    MainDataSetTableAdapters.ItemTableAdapter itemTable = new MainDataSetTableAdapters.ItemTableAdapter();

    protected void Page_Load(object sender, EventArgs e)
    {
        DataTable itemDataTable = new DataTable();
        itemDataTable = itemTable.GetData();
        itemDataList.DataSource = itemDataTable;
        itemDataList.DataBind();
    }

    protected void ItemDataList_ItemCommand(object source, DataListCommandEventArgs e)
    {
        Session["ItemID"] = e.CommandArgument.ToString();
        Response.Redirect("View.aspx?ItemID=" + e.CommandArgument.ToString());
    }
}