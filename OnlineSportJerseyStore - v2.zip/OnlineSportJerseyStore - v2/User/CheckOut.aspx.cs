﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class User_CheckOut : System.Web.UI.Page
{
    MainDataSetTableAdapters.CustomerTableAdapter customerTable = new MainDataSetTableAdapters.CustomerTableAdapter();
    MainDataSetTableAdapters.ItemTableAdapter itemTable = new MainDataSetTableAdapters.ItemTableAdapter();
    MainDataSetTableAdapters.OrderTableAdapter orderTable = new MainDataSetTableAdapters.OrderTableAdapter();
    MainDataSetTableAdapters.OrderDetailTableAdapter orderDetailTable = new MainDataSetTableAdapters.OrderDetailTableAdapter();
    MainDataSetTableAdapters.PaymentTableAdapter paymentTable = new MainDataSetTableAdapters.PaymentTableAdapter();
    private DataTable dataTable1 = new DataTable();
    private DataTable dataTable2 = new DataTable();
     int total;
     String todayDate;

    protected void SelectTempTbl()
    {
        DataTable displayDataTable = new DataTable();
        displayDataTable.Columns.Clear();
        displayDataTable.Rows.Clear();
        displayDataTable.Columns.Add("No");
        displayDataTable.Columns.Add("ItemID");
        displayDataTable.Columns.Add("ItemName");
        displayDataTable.Columns.Add("CatName");
        displayDataTable.Columns.Add("Price");
        displayDataTable.Columns.Add("Qty");
        var index = 0;
        foreach (DataRow dataRow1 in dataTable1.Rows)
        {
            DataRow dataRow;
            var itemID = Convert.ToInt32(dataRow1[0].ToString());
            dataTable2 = itemTable.Item_Select_By_ItemID(itemID);
            foreach (DataRow dataRow2 in dataTable2.Rows)
            {
                dataRow = displayDataTable.NewRow();
                dataRow[0] = index + 1;
                dataRow[1] = dataRow2[1];
                dataRow[2] = dataRow2[3];
                dataRow[3] = dataRow2[2];
                dataRow[4] = dataRow2[4];
                dataRow[5] = dataRow1[1];
                displayDataTable.Rows.Add(dataRow);
                checkOutGridView.DataSource = displayDataTable;
                checkOutGridView.DataBind();
                index = index + 1;
            }
        }
    }

    protected void TotalAndDay()
    {
        var day = String.Empty;
        var month = String.Empty;
        var year = String.Empty;
        var quantity = 0;
        var price = 0;
        foreach (GridViewRow checkOutGridViewRow in checkOutGridView.Rows)
        {
            price = Convert.ToInt32(checkOutGridViewRow.Cells[4].Text.ToString());
            quantity = Convert.ToInt32(checkOutGridViewRow.Cells[5].Text.ToString());
            total += Convert.ToInt32(quantity * price);
            
        }
        
        totalTextBox.Text = total.ToString();
        day = String.Format("{0:D2}", DateTime.Now.Day);
        month = String.Format("{0:D2}", DateTime.Now.Day);
        year = DateTime.Today.Year.ToString();
        todayDate = String.Format("{0}/{1}/{2}", day, month, year);
       
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        dataTable1 = (DataTable)Session["TempTbl"];
        if (!IsPostBack)
        {
            if (Session["TempTbl"] == null)
            {
                Response.Redirect("Default.aspx");
            }
            else
            {
                if (dataTable1.Rows.Count <= 0)
                {
                    Response.Redirect("Default.aspx");
                }
                else
                {
                    this.SelectTempTbl();
                }
            }
           
        }
        TotalAndDay();
        
        if (Session["LogInCustomer"] == null)
        {
            Session["URL"] = "CheckOut.aspx";
            Response.Redirect("LogIn.aspx");
        }
        else
        {
            dataTable2 = customerTable.Customer_Select_By_CustID(Convert.ToInt32(Session["LogInCustomer"].ToString()));
        }
    }


    protected void PaymentDropDownList_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (paymentDropDownList.SelectedIndex == 0)
        {
            messageLabel.Text = "Select Payment Option";
            cashButton.Visible = false;
            cardPanel.Visible = false;
        }
        else if (paymentDropDownList.SelectedIndex == 1 || paymentDropDownList.SelectedIndex == 2)
        {
            
            messageLabel.Text = String.Empty;
            cashButton.Visible = false;
            cardPanel.Visible = true;
        }
        else if (paymentDropDownList.SelectedIndex == 3)
        {
            
            messageLabel.Text = String.Empty;
            cardPanel.Visible = false;
            cashButton.Visible = true;
        }
        
    }


    protected void PayButton_Click(object sender, EventArgs e)
    {
        this.InsertData();
        this.InsertPaymentForPayButton();
        this.TotalAndDay();
        DataTable dataTable = (DataTable)Session["TempTbl"];
        dataTable.Rows.Clear();
        Response.Redirect("Thanks.aspx");
    }


    protected void CashButton_Click(object sender, EventArgs e)
    {
        this.InsertData();
        this.InsertPaymentForCashButton();
        DataTable dataTable = (DataTable)Session["TempTbl"];
        dataTable.Rows.Clear();
        Response.Redirect("Thanks.aspx");
    }

    private void InsertPaymentForPayButton()
    {
        var rowIndex = orderTable.GetData().Rows.Count;
        var orderID = Convert.ToInt32(orderTable.GetData().Rows[rowIndex - 1][0].ToString());
        paymentTable.Payment_Insert(paymentDropDownList.SelectedItem.Text, System.DateTime.Now, Convert.ToInt32(totalTextBox.Text),
        orderID, cardNumberTextBox.Text, bankDropDownList.SelectedItem.Text, Session["customerName"].ToString());
    }

    private void InsertPaymentForCashButton()
    {
        var ipDate = System.DateTime.Now; 
        var rowIndex = orderTable.GetData().Rows.Count;
        var orderID = Convert.ToInt32(orderTable.GetData().Rows[rowIndex - 1][0].ToString());
        paymentTable.Payment_Insert(paymentDropDownList.SelectedItem.Text, System.DateTime.Now, Convert.ToInt32(totalTextBox.Text),
        orderID, "", "", Session["customerName"].ToString());
    }

    private void InsertData()
    {
        //var shippingAddress = dataTable2.Rows[0][3].ToString();
        var shippingAddress = shippingAddressTextBox.Text;
        orderTable.Order_Insert(System.DateTime.Now, Convert.ToInt32(Session["LogInCustomer"].ToString()),
        shippingAddress, Convert.ToInt32(total.ToString()), "Order...", Session["customerName"].ToString());
        var index = 0;
        var rowIndex = orderTable.GetData().Rows.Count;
        var orderID = Convert.ToInt32(orderTable.GetData().Rows[rowIndex - 1][0].ToString());

        foreach (GridViewRow checkOutGridViewRow in checkOutGridView.Rows)
        {
            orderDetailTable.OrderDetail_Insert(orderID, Convert.ToInt32(dataTable1.Rows[index][0].ToString()),
            Convert.ToInt32(checkOutGridViewRow.Cells[4].Text.ToString()), Convert.ToInt32(checkOutGridViewRow.Cells[5].Text.ToString()));
            index = index + 1;
        }

        foreach (DataRow dataRow1 in dataTable1.Rows)
        {
            var itemID = Convert.ToInt32(dataRow1[0].ToString());
            var quantity = Convert.ToInt32(dataRow1[1].ToString());
            itemTable.Item_Update_ForSell(itemID, quantity);
        }
    }
}