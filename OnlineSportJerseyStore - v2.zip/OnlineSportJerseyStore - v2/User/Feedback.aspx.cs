﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class User_Feedback : System.Web.UI.Page
{
    MainDataSetTableAdapters.FeedbackTableAdapter feedbackTable = new MainDataSetTableAdapters.FeedbackTableAdapter();

    protected void SendButton_Click(object sender, EventArgs e)
    {
        feedbackTable.Feedback_Insert(customerNameTextBox.Text, feedbackTextBox.Text);
        feedbackTextBox.Text = String.Empty;
        customerNameTextBox.Text = String.Empty;
        messageLabel.Text = "Feedback Sent Successfully";
    }
}