﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class User_Registration : System.Web.UI.Page
{
    MainDataSetTableAdapters.CustomerTableAdapter customerTable = new MainDataSetTableAdapters.CustomerTableAdapter();

   
    protected void RegisterButton_Click(object sender, EventArgs e)
    {
        if (this.IsNotDuplicate())
        {
            customerTable.Customer_Insert(nameTextBox.Text, addressTextBox.Text,
            mobileTextBox.Text, emailTextBox.Text, passwordTextBox.Text);
            errorLabel.Text = "Save Successfully One Record";
            Response.Redirect("LogIn.aspx");
        }
    }

    private bool IsNotDuplicate()
    {
        if (customerTable.Customer_Select_By_Email(emailTextBox.Text).Rows.Count > 0)
        {
            errorLabel.Text = "This Customer is already exist";
            emailTextBox.Focus();
            return false;
        }
        else if (customerTable.Customer_Select_By_CustName(nameTextBox.Text).Rows.Count > 0)
        {
            errorLabel.Text = "This Customer is already exist";
            nameTextBox.Focus();
            return false;
        }
        else
        {
            return true;
        }
    }
}